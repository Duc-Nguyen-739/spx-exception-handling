# Add Group Members

**Source:** https://open.seatalk.io/docs/Add-Group-Members

## API Description

This API allows a bot to invite users and/or bots into a group chat where the caller bot is a member.

- The target group must allow members to add members.

- The caller bot must be a member of the target group.

- "employee_codes" and "bot_seatalk_ids" can be sent separately or together.

- The combined number of requested members must be between 1 and 30. Duplicates count toward the limit.

- Rate Limit: 10 group-member requests per app per minute.

- User members must be in the caller bot's Service Scope.

- Bot members must pass the Bot Access checks before they are added.

Request Method: `POST`End Point: https://openapi.seatalk.io//messaging/v2/group_chat/add_group_members (https://openapi.seatalk.io//messaging/v2/group_chat/add_group_members)

## Request Parameter

### Headers

| Parameter | Type | Mandatory | Description | Sample |
| --- | --- | --- | --- | --- |
| Authorization | string | Yes | App Access obtained through the Get App Access Token API | Bearer c8bda0f77ef940c5bea9f23b2d7fc0d8 |
| Content-Type | string | Yes | Request header format | application/json |

### Body Parameters

| Parameter | Type | Mandatory | Description | Default |
| --- | --- | --- | --- | --- |
| group_id | string | Yes | The group chat ID. Encrypted ID of the target group chat. | N/A |
| employee_codes | string[] | Conditional | Employee codes of user members to add. Users must be in the caller bot's Service Scope. | [ ] |
| bot_seatalk_ids | string[] | Conditional | SeaTalk IDs of bot members to add. Each bot is validated against Bot Access and its owner's Service Scope. | [ ] |

### Request Sample

```json
{
"group_id": "encrypted_group_id",
"employee_codes": [
"employee_code_001",
"employee_code_002"
],
"bot_seatalk_ids": [
"bot_seatalk_id_001"
]
}
```

For each target bot "B", the caller bot "A" must have the required bot-invitation API permission, "B.allow_bot_access" must be "true", "A" must have an owner, and "A.owner" must be in "B's" Service Scope. "A" and "B" must belong to the same enterprise, "B" must be enabled in the current enterprise, and "BotOnlineStatus(B)" must not be "AppStatusOffline".

## Response Parameter

| Parameter | Type | Description |
| --- | --- | --- |
| code | int | "0" when the request is processed. Per-member failures are returned in "add_failed". |
| message | string | Error description for a non-zero "code"; "success" when "code" is "0". |
| total_num | int | Total number of requested users and bots. |
| success_num | int | Number of members successfully added. |
| error_num | int | Number of members that failed to be added. |
| add_failed | object[] | Members that failed to be added. Existing user fields are retained; bot items include "member_type" and "seatalk_id". |
| ∟member_type | string | "bot" for a bot failure item. Omitted for legacy user failure items. |
| ∟seatalk_id | string | SeaTalk ID of the bot that failed to be added. Present for bot failure items. |
| ∟email | string | Email of the user that failed to be added. Present for user failure items. |
| ∟employee_code | string | Employee code of the user that failed to be added. Present for user failure items. |
| ∟error_code | int | Error code for the failed member. |
| ∟error_message | string | The description of error_code. |

### Response Sample

```json
{
"code": 0,
"message": "success",
"total_num": 3,
"success_num": 3,
"error_num": 0,
"add_failed": []
}
```

### Bot Failure Sample

```json
{
"member_type": "bot",
"seatalk_id": "bot_seatalk_id_001",
"error_code": 7007,
"error_message": "Bot Access Toggle is not enabled"
}
```

## Error Codes

| Value | Description | Resolution |
| --- | --- | --- |
| 101 | API is rejected due to rate limit control | Comply with the limit of 10 group-member requests per app per minute. |
| 102 | Request body contains invalid input | Provide `group_id` and at least one member across the two arrays; the combined count must be 1–30. |
| 3001 | User not found with the current code | Check the user employee code. |
| 3003 | User is not signed in to SeaTalk | Ensure that the user has signed in on SeaTalk |
| 4012 | No permission | Ensure that the caller bot is in the group and member management is allowed. |
| 4013 | Member cannot be contacted due to organisation policy. | Check whether the member can be added under the organisation policy. |
| 7000 | Group chat not found with the current code | Ensure that `group_id` is correct. |
| 7001 | Bot is not a member of the group chat | Ensure that the caller bot is in the target group. |
| 7002 | Group is full | Ensure that there is sufficient space in the group. |
| 7005 | User is already in the group | Ensure that the target user is not already a member. |
| 7006 | Target bot not found. | Ensure that the target bot SeaTalk ID is correct. |
| 7007 | Target bot's Bot Access Toggle is disabled. | Enable `allow_bot_access` for the target bot. |
| 7008 | Caller bot owner not found. | Ensure that the caller bot has an owner. |
| 7009 | Caller bot owner is not in the target bot's Service Scope. | Add the caller bot owner to the target bot's Service Scope. |
| 7010 | Caller and target bots belong to different enterprises. | Use bots from the same enterprise. |
| 7011 | Target bot is not enabled or is offline. | Enable the target bot and ensure `BotOnlineStatus(B) != AppStatusOffline`. |
| 7012 | Target bot is already in the group. | Ensure that the target bot is not already a member. |

##