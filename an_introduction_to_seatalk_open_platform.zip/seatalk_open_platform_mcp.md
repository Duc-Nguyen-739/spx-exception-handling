# Seatalk Open Platform MCP

**Source:** https://open.seatalk.io/docs/Seatalk-Open-Platform-MCP

The SeaTalk Open Platform MCP gives your AI assistant direct access to&nbsp;official SeaTalk Open Platform documentation. It will queries an Alpha Knowledge expert and returns accurate, cited answers about&nbsp;SeaTalk APIs, bots, authentication, webhooks, and more.

## Network Access Requirement

This MCP server is only accessible from the internal office network. You must be connected to the office network or VPN before attempting to connect. Requests made from an external network will fail to reach the server.

## Connecting to the Server

No local installation is required. Point your MCP client at:&nbsp;&nbsp;`https://open.seatalk.io/mcp`&nbsp;

&nbsp;

### Claude Code

#### Option 1 - CLI command (recommended)

- Run this once in your terminal: 
```
claude mcp add --transport http seatalk-open-platform https://open.seatalk.io/mcp
```

- By default this saves to the current project (`.mcp.json`). To install it for all your projects instead, add `--scope user`: 
```
claude mcp add --transport http --scope user seatalk-open-platform https://open.seatalk.io/mcp
```

#### Option 2 - Manual config

- Create or update `.mcp.json` in your project root: 
```
{
"mcpServers": {
"seatalk-open-platform": {
"type": "http",
"url": "https://open.seatalk.io/mcp"
}
}
```

- Reload Claude Code (`/mcp` & reconnect, or restart the IDE). The seatalk-open-platform server will appear in your tool list.

- To allow the tool without a permission prompt on every call, add this to `.claude/settings.json`: 
```json
{
"permissions": {
"allow": [
"mcp__seatalk-open-platform__ask_seatalk_expert"
]
}
}
```

### OpenAI Codex

Codex reads MCP configuration from&nbsp;`~/.codex/config.toml` (global) or&nbsp;`.codex/config.toml`&nbsp;in your project root (project-scoped). Add the following:

```
[mcp_servers.seatalk-open-platform]
url = "https://open.seatalk.io/mcp"
```

Save the file and restart Codex. The tool will be available in your next session.