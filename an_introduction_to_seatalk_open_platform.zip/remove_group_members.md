# Remove Group Members

**Source:** https://open.seatalk.io/docs/Remove-Group-Members

## API Description

This API allows a bot to remove group members. 

- The bot must be a member of the target group.

- The target group must allow members to add/remove members.

- Group owners and administrators cannot be removed.

- "employee_codes" and "bot_seatalk_ids" can be sent separately or together.

- The combined number of requested members must be between 1 and 30. Duplicates count toward the limit.

- Rate Limit: 10 group-member requests per app per minute.

- User members must be in the caller bot's Service Scope.

- Removing a bot does not require "allow_bot_access", the bot owner's Service Scope, same- company validation, or an online-status check. Existing group permission checks still apply.

Request Method: `POST`End Point: https://openapi.seatalk.io/messaging/v2/group_chat/remove_group_members (https://openapi.seatalk.io/messaging/v2/group_chat/remove_group_members)

## Request Parameter

### Headers

| Parameter | Type | Mandatory | Description | Sample |
| --- | --- | --- | --- | --- |
| Authorization | string | Yes | App access token obtained through the Get App Access Token API | Bearer c8bda0f77ef940c5bea9f23b2d7fc0d8 |
| Content-Type | string | Yes | Request header format | application/json |

### Body Parameters

| Parameter | Type | Mandatory | Description | Default |
| --- | --- | --- | --- | --- |
| group_id | string | Yes | Encrypted ID of the target group chat. | N/A |
| employee_codes | string[] | Conditional | Employee codes of user members to remove. Users must be in the caller bot's Service Scope. | [ ] |
| bot_seatalk_ids | string[] | Conditional | SeaTalk IDs of bot members to remove. Bot Access Toggle, bot owner scope, company, and online-status checks do not apply to removal. | [ ] |

- At least one of "employee_codes" or "bot_seatalk_ids" must contain an item.

- The combined number of items in both arrays must not exceed 30.

### Request Sample

```json
{
"group_id": "encrypted_group_id",
"employee_codes": [
"employee_code_001",
"employee_code_002"
],
"bot_seatalk_ids": [
"bot_seatalk_id_001"
]
}
```

## Response Parameter

| Parameter | Type | Description |
| --- | --- | --- |
| code | int | "0" when the request is processed. Per-member failures are returned in "remove_failed". |
| message | string | Error description for a non-zero "code"; "success" when "code" is "0". |
| total_num | int | Total number of requested users and bots. |
| success_num | int | Number of members successfully removed. |
| error_num | int | Number of members that failed to be removed. |
| remove_failed | object[] | Members that failed to be removed. Existing user fields are retained; bot items include "member_type" and "seatalk_id". |
| ∟member_type | string | "bot" for a bot failure item. Omitted for legacy user failure items. |
| ∟seatalk_id | string | SeaTalk ID of the bot that failed to be removed. Present for bot failure items. |
| ∟email | string | Email of the user that failed to be removed. Present for user failure items. |
| ∟employee_code | string | Employee code of the user that failed to be removed. Present for user failure items. |
| ∟error_code | int | Error code for the failed member. |
| ∟error_message | string | Description of error_code |

### Response Sample

```json
{
"code": 0,
"message": "success",
"total_num": 3,
"success_num": 3,
"error_num": 0,
"remove_failed": []
}
```

### Bot Failure Sample

```json
{
"member_type": "bot",
"seatalk_id": "bot_seatalk_id_001",
"error_code": 7004,
"error_message": "Bot is not a member of the group chat"
}
```

## Error Codes

| Value | Description | Resolution |
| --- | --- | --- |
| 101 | API is rejected due to rate limit control | Comply with the limit of 10 group-member requests per app per minute. |
| 102 | Request body contains invalid input | Provide `group_id` and at least one member across the two arrays; the combined count must be 1–30. |
| 3001 | User not found with the current code | Check the user employee code and group membership. |
| 3003 | User is not signed in to SeaTalk | Ensure that the user has signed in on SeaTalk |
| 4012 | No permission | Ensure that the caller bot is in the group and group member management is allowed; do not target a group owner or administrator. |
| 4013 | Member cannot be contacted due to organisation policy. | Check whether the member can be removed under the organisation policy. |
| 7000 | Group chat not found with the current code | Ensure that "group_id" is correct. |
| 7001 | Bot is not a member of the group chat | Ensure that the caller bot is in the target group. |
| 7004 | Target member is not a member of the group chat. | Ensure that the target user or bot is in the target group. |