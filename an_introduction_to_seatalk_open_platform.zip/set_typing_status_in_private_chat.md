# Set Typing Status in Private Chat

**Source:** https://open.seatalk.io/docs/Set-Typing-Status-in-Private-Chat

Typing status can only be triggered by bots in SeaTalk v3.55 or later

## API Description

Set the "Typing..." indicator in a private chat between your bot and its user. This API should be used when your bot receives an event from a user in a private chat and needs an extended amount of time to generate a response. On successful call, the typing indicator is displayed in the chatroom for 4s.

Prerequisite: 

- The employee_code from the event received must match the employee_code from the event received

Request Method: POST

End Point: https://openapi.seatalk.io/messaging/v2/single_chat_typing (https://openapi.seatalk.io/messaging/v2/single_chat_typing)

Rate Limit: 300/min

## Request Parameters

Header

| Parameter | Type | Mandatory | Description | Default | Sample |
| --- | --- | --- | --- | --- | --- |
| Authorization | string | Yes | From Get App Access Token | N/A | Bearer c8bda0f77ef940c5bea9f23b2d7fc0d8 |
| Content-Type | string | Yes | Request header format | N/A | application/json |

Body

| Parameter | Type | Mandatory | Description | Default | Length Limit | Sample |
| --- | --- | --- | --- | --- | --- | --- |
| employee_code | string | Yes | The employee_code of the user | N/A | N/A | "e_12345678" |
| thread_id | string | No | The thread ID. Provide thread_id to trigger typing status in a thread. To start typing in an unthreaded root message, define thread_id as the message_id of the root message | N/A | N/A | "abcdef" |

Request Sample

```json
{
"employee_code": "e_10983748"
}
```

## Response Parameters

Body

| Parameter | Type | Description | Sample |
| --- | --- | --- | --- |
| code | int | Refer to Error Code for explanations | 0 |

##