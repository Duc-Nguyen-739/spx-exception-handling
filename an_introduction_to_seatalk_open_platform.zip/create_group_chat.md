# Create Group Chat

**Source:** https://open.seatalk.io/docs/create-group-chat

Requires SeaTalk App version 3.50.0 or above, released at the end of November 2024

## API Description

This API allows a bot to create a group chat.

- Group member list is optional. If provided, its size must be between 1 and 30.

- Rate Limit: 100 groups per app each day, 10 groups per app every minute.

- User members are added only when they are in the caller bot's Service Scope.

- Since February 6, 2025, this API no longer validates the user's subscriber identity

- The bot that created the group chat will be added to the group automatically.

- Bot members are identified by member_type and seatalk_id. When a bot cannot be added, its seatalk_id is returned separately in bots_not_added.

Request API Permission: Create Group Chat Request Method: `POST`End Point: https://openapi.seatalk.io/messaging/v2/group_chat/create_group (https://openapi.seatalk.io/messaging/v2/group_chat/create_group)

## Request Parameter

### Headers

| Parameter | Type | Mandatory | Description | Sample |
| --- | --- | --- | --- | --- |
| Authorization | string | Yes | Obtained through the Get App Access Token API | Bearer c8bda0f77ef940c5bea9f23b2d7fc0d8 |
| Content-Type | string | Yes | Request body format | application/json |

### Body Parameters

| Parameter | Type | Mandatory | Description | Length Limit |
| --- | --- | --- | --- | --- |
| group_owner | string | Yes | Employee code of the human group owner. A bot cannot be the group owner. The user must be in the caller bot's Service Scope. | N/A |
| group_member_list | object[] | No | Members invited into the group. If provided, the list must contain 1–30 users and/or bots. | N/A |
| ∟member_type | string | Conditional | user or bot. If omitted with employee_code, the item is treated as a user for backward compatibility. | user when omitted with employee_code |
| ∟employee_code | string | Conditional | Employee code of a user member. Do not use it for a bot member. | N/A |
| ∟seatalk_id | string | Conditional | SeaTalk ID of a bot member. Required when member_type is bot. | N/A |
| ∟role | integer | No | 0 - "Group member" 1 - "Group admin" Note: Bot members can only use role `0`; bots cannot be administrators. | 0 |
| group_name | string | No | Group name. If omitted, a name is generated from the users until the limit is reached. | 120 characters |
| group_settings | object | No | Group settings. | NA |
| ∟chat_history_for_new_members | integer | No | The chat history settings 0 - "Off" 1 - "24 hours" 2 - "7 days" | NA |

### Identifier Rules:

- A user item uses employee_code; a bot item uses member_type: "bot" and seatalk_id.

- employee_code and seatalk_id must not be mixed in the same item.

- member_type: "bot" without seatalk_id is invalid.

- An unknown member_type is invalid.

### Request Sample

```json
{
"group_owner": "employee_code_owner",
"group_member_list": [
{
"employee_code": "employee_code_user",
"role": 0
},
{
"member_type": "bot",
"seatalk_id": "bot_seatalk_id"
}
],
"group_name": "Group Chat Test 123",
"group_settings": {
"chat_history_for_new_members": 2
}
}
```

## Response Parameter

| Parameter | Type | Description |
| --- | --- | --- |
| code | integer | 0 when the group is created successfully. Refer to the Error Code table for failures. |
| group_id | string | Encrypted ID of the created group. |
| users_not_added | string[] | Employee codes of user members that were not added. This existing field is retained for backward compatibility. |
| bots_not_added | string[] | SeaTalk IDs of bot members that were not added. This field is empty when all requested bots are added. |

Note: The group can be created successfully even when some requested members cannot be added. User failures remain in users_not_added. Bot failures are returned as SeaTalk IDs only; this field does not contain per-bot member_type, error_code, or error_message objects:

```json
[
"bot_seatalk_id"
]
```

### Response Sample

```json
{
"code": 0,
"group_id": "NTk2NjAxMDUyMzMz",
"users_not_added": [],
"bots_not_added": []
}
```

## Error Codes

### Request-Level Errors

| Value | Description | Resolution |
| --- | --- | --- |
| 102 | Request body contains invalid input | Ensure that group_owner is provided and group_member_list contains 1 - 30 valid employee codes |
| 3001 | User not found with the current code | Ensure group_owner belongs to a valid employee in the bot's scope. |
| 3002 | User is not in the service scope of the bot | Add the user to the caller bot's Service Scope. |

### Bot Member Validation

Each requested bot is validated independently. A bot is added only when all of the following conditions are satisfied:

- The caller app has the Create Group Chat permission.

- The target bot has "allow_bot_access = true".

- The caller bot has an owner, and the owner is in the target bot's Service Scope.

- The caller and target bots belong to the same enterprise.

- "BotOnlineStatus(target) != AppStatusOffline".

- The bot is requested as a normal member, not an administrator.

When a condition fails, the group can still be created and the target bot's `seatalk_id` is added to `bots_not_added`. No per-bot error code or error message is returned in this list.

## Response Sample: Partial Success

```json
{
"code": 0,
"group_id": "NTk2NjAxMDUyMzMz",
"users_not_added": [],
"bots_not_added": [
"bot_seatalk_id"
]
}
```

## Bot Added Callback

- For each bot successfully added to the newly created group, the existing "bot_added_to_group_chat" callback is sent to that bot once. 

- Bots listed in "bots_not_added" do not receive this callback.

- The callback identifies the inviter as the caller bot by populating "inviter.seatalk_id"; "inviter.employee_code" and "inviter.email" are empty.