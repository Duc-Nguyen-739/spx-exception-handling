# Update Employee

**Source:** https://open.seatalk.io/docs/update-employee

## API Description

Use this API to update an existing employee's information in your organization. 

Note:

- This API requires Onboard/Update/Re-board Employee permission and the relevant Data Scope.

- If some fields are not passed in inside a request, they won't get updated. SeaTalk will only update fields that are passed in.

Request Method: `POST`

End Point: https://openapi.seatalk.io/oa_sync/employees/update

## Request Parameter

Header

| Parameter | Type | Mandatory | Description | Default | Sample |
| --- | --- | --- | --- | --- | --- |
| Authorization | string | Yes | Obtained through the Get App Access Token API | N/A | Bearer c8bda0f77ef940c5bea9f23b2d7fc0d8 |
| Content-Type | string | Yes | Request header format | N/A | application/json |

Body

| Parameter | Type | Mandatory | Max Length |
| --- | --- | --- | --- |
| employees | []UpdateEmployeeParam | Yes | 50 |

UpdateEmployeeParam

| Parameter | Type | Mandatory | Max Length | Description | Default | Sample |
| --- | --- | --- | --- | --- | --- | --- |
| employee_code | string | Yes | 30 char | - The unique Identifier of the employee in the organization - It must belong to an existing employee | N/A | "202101" |
| name | string | No | 100 char | The name of the employee | N/A | |
| hand_phone | string | No | 100 char | - The phone number of the employee - Must be in a valid phone number format and unique within the organization | N/A | |
| company_email | string | No | 100 char | - The company email of the employee - Must be in a valid email format and unique within the organization | N/A | |
| personal_email | string | No | 100 char | - The personal email of the employee - Must be in a valid email format | N/A | |
| department_code | string | No | 255 char | - The department this employee belongs to - Must be a valid department_code within the organization | N/A | |
| report_to | string | No | 255 char | - The employee_code of the reporting manager - Must be a valid employee_code within the organization | N/A | |
| birth_date | string | No | 100 char | - The date of birth of the employee - Must be in a valid date format: "YYYY-MM-DD" or "MM-DD" | N/A | |
| board_date | string | No | N/A | - The onboarding date - Must be valid date format: "YYYY-MM-DD" | N/A | |
| probation_end_date | string | No | N/A | - The end date of this employee's probation - Must be valid date format: "YYYY-MM-DD" - Must be later than the employee's board_date | N/A | |
| gender | int | No | N/A | 1: Male 2: Female 3: Others | N/A | |
| martial_status | int | No | N/A | 1: Single 2: Married 3: Divorced 4: Widowed 5: Others | N/A | |
| address | string | No | 255 char | The address of the employee | N/A | |
| employment_type | int | No | N/A | 1: Full-time 2: Part-time 3: Shift work 4: Contractor 5: Internship 6: Others | N/A | |
| number_of_children | int | No | N/A | The number of children the current employee has | N/A | |
| job_title | string | No | 255 char | - The employee's job title - Must correspond to one of the Job Titles set in the current organization's OA system | N/A | |
| office | string | No | 255 char | - The employee's office - Must correspond to one of the Offices set in the current organization's OA system | N/A | |
| payroll_company | string | No | 255 char | - The employee's payroll company - Must correspond to one of the Payroll Companys set in the current organization's OA system | N/A | |
| rank | string | No | 255 char | - The employee's rank - Must correspond to one of the Ranks set in the current organization's OA system | N/A | |

Request Sample

```json
{
"employees": [
{
"employee_code": "e_pfu5zya3",
"office": "Shanghai",
"payroll_company": "sea limited"
},
{
"employee_code": "e_226n0tn6",
"office": "Guangzhou",
"payroll_company": "sea limited"
}
]
}
```

## Response Parameter

Result Fields

| Parameters | Type | Description |
| --- | --- | --- |
| code | int | Refer to Error Code for explanations |
| message | string | - The error message - Return empty string if the request is successful |
| rid | string | The request ID |
| update_result | UpdateEmployeeResult | The update request result |

UpdateEmployeeResult

| Parameters | Type | Description |
| --- | --- | --- |
| employees | []Employee | A list of employees |
| total_num | int | The total number of employees in this request |
| success_num | int | The number of successfully updated employees in this request |
| error_num | int | The Number of employees that haven't been updated successfully in this request |

Employee

| Parameters | Type | Description |
| --- | --- | --- |
| email | string | The email of the target employee |
| employee_code | string | The employee_code of this employee |
| error | string | - Error message for this employee if he/she hasn't been updated successfully - Empty if success |
| error_code | string | - Error code for this employee's onboarding request - 0 if success |

Response Sample

```json
{
"code": 0,
"message": "",
"rid": "bb10b5e3-8ca2-4f6b-abd0-b1d6f9d2b712",
"update_result": {
"employees": [
{
"email": "",
"employee_code": "e_pfu5zya3",
"error": "",
"error_code": 0
},
{
"email": "",
"employee_code": "e_226n0tn6",
"error": "",
"error_code": 0
}
],
"total_num": 2,
"success_num": 2,
"error_num": 0
}
}
```