# Web SDK Error Code

**Source:** https://open.seatalk.io/docs/web-sdk_error-code

SeaTalk will return HTTP status 200 upon successful request. However, this does not mean that the action was successful. A code is returned in the response body to give a description of the error. Any non-zero code indicates the occurrence of an error.

Please refer to the table below for the error messages and corresponding resolutions.

| Value | Description | Resolution |
| --- | --- | --- |
| 0 | Success | / |
| 1000 | Internal error from the SeaTalk native app | Check your code for errors |
| 1001 | Invalid parameters | Ensure that the request parameters are valid |
| 1002 | Function not found | Ensure that the function exists in your app |

For more information or further clarification on any error code, please contact us via the following SeaTalk groups:

![](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOJ9-AOzbfa1JERwIACc?sign=1728378285.9147093-jZ5s0-0-6becff0713f642a117a3e92e5136717b) . ![](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOIn5AGiFf61JEUgEACc?sign=1728378303.7159295-RFhft-0-a28709a624e3c525f84bbce30c4f5409)