# Update Employee Avatar

**Source:** https://open.seatalk.io/docs/update-employee-avatar

## API Description

Use this API to update an existing employee's avatar. 

Note:

- This API requires Update Employee Avatar permission

Request Method: `POST`

End Point: https://openapi.seatalk.io/oa_sync/employees/update_avatar

## Request Parameter

Header

| Parameter | Type | Mandatory | Description | Default | Sample |
| --- | --- | --- | --- | --- | --- |
| Authorization | string | Yes | Obtained through the Get App Access Token API | N/A | Bearer c8bda0f77ef940c5bea9f23b2d7fc0d8 |
| Content-Type | string | Yes | Request header format | N/A | "multipart/form-data; boundary=auto calculated" |

Body

| Parameter | Type | Mandatory | Description | Size/Length Limit |
| --- | --- | --- | --- | --- |
| employee_code | string | Yes | The employee's employee_code | Max: 30 characters |
| avatar_image | Binary | Yes | - The image of the employee's new avatar - Must be a JEPG, PNG, JPG file - SeaTalk Open Platform will crop out a square in the middle of the image and compress the square image's size to less than 400*400 px | Max: 1 MB |

## Response Parameter

Result Fields

| Parameters | Type | Description |
| --- | --- | --- |
| code | int | Refer to Error Code for explanations |
| message | string | - Error Message - Return the empty string if the request is successful |
| rid | string | The request ID |

Response Sample

```json
{
"code": 0,
"message": "",
"rid": "bb10b5e3-8ca2-4f6b-abd0-b1d6f9d2b712"
}
```