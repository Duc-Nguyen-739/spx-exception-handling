# Changelog

**Source:** https://open.seatalk.io/docs/sop-changelog

Hi SeaTalk Open Platform developers, you can find all changelogs related to the open platform in this doc. We will also post important notices here too!

## 22 Sep 2026

Bots Can Manage Other Bots in Group Chats

Bots can now add and remove other bots in group chats through the following APIs:

- Create Group Chat

- Add Group Members

- Remove Group Members

For create and add operations, target bots must have Bot Access enabled, be enabled and online, and allow access through their Service Scope. Remove operations follow the existing group-member removal permissions.

Please refer to our API documentation for more information.

## 24 Jun 2026

Bots and System Accounts To Send Table-Formatted Text Messages

This is supported across all bot and system account message send and receive APIs. Please refer to our API docs for more information:

- Send a Message with Formats

- Introduction to Received Message Types

## 12 Jun 2026

Streaming Messages for Bots

Bots can now send streaming messages that display content progressively to recipients — similar to a typewriter effect. Streaming is supported in 1-on-1 chats and group chats, for both text and interactive messages.

- No additional permission required. 1-on-1 streaming uses the existing Send Message to Bot User permission; group chat streaming uses the existing Send Message to Group Chat permission.

- Requires SeaTalk App version 3.67 or later. Recipients on earlier versions will see only the final message after the stream is closed.

- Please refer to our API docs for more information: Send Streaming Messages

## 21 May 2026

Group Type Detection for Bots

SeaTalk now lets bots detect whether a group is an Internal Group or External Group, just like users can. This means you can tailor your security settings based on the group type whenever you need to. ​Please refer to our API docs for more information.

- Bot Added to Group Chat: https://open.seatalk.io/docs/event-bot-added-to-group-chat

- Get Group Info: https://open.seatalk.io/docs/get-group-info

- Group Chat Converted to External Group: https://open.seatalk.io/docs/group_chat_converted_to_external_group

## 23 Jan 2026

Thread Support in 1-1 Chat Between User and Bot

Please refer to our API docs for more information.

- Send Message to a Bot User: https://open.seatalk.io/docs/messaging_send-message-to-bot-user_

- Set Typing Status in Private Chat: https://open.seatalk.io/docs/Set-Typing-Status-in-Private-Chat

- Get Thread by Thread ID in Private Chat: 

- Event: Message Received From Bot User: https://open.seatalk.io/docs/event_message_received_from_bot_subscriber

## 21 Nov 2025

New APIs for Adding and Removing Members in Group Chats

- 2 new APIs have been released, allowing bots to invite and remove group members in existing groups!

- Please refer to our API docs for more information. Add Group Members: https://open.seatalk.io/docs/Add-Group-Members

- Remove Group Members: https://open.seatalk.io/docs/Remove-Group-Members

Interactive Message Updates

- New element type supported: image

- Title field character limit has been increased from 60 to 120

## 8 Aug 2025

New Event: New Message Received from Thread

- With this event, your bots will be able to receive users' messages in threads that your bots were following, without users needing to mention them in threads first!

- Please refer to the documentation here: https://open.seatalk.io/docs/new_message_received_from_thread

## 7 Aug 2025

Interactive Message Updates

- New interactive component: Button groups - with this component, a maximum of 3 buttons can be laid out in the same row, increasing message readability

- Description field character limit has been increased from 500 to 1000

- All existing APIs and events can now retrieve interactive message type

## 10 Jul 2025

New Event: User Entered Chatroom with Bot

- This event notifies your bot when a user enters a chatroom with it, enabling you to configure welcome messages and monitor usage behaviour of your bot.

- Please refer to the documentation here: https://open.seatalk.io/docs/user_enter_chatroom_with_bot

## 12 Jun 2025

New APIs for Bot Typing Status

- 2 new APIs have been released, allowing bots to trigger typing status in private chats, group chats and threads!

- Please refer to our API docs for more information. https://open.seatalk.io/docs/Set-Typing-Status-in-Private-Chat

- https://open.seatalk.io/docs/Set-Typing-Status-in-Group-Chat

Note: For bot users to view the typing status, they must be on SeaTalk version 3.55 or later

## 29 May 2025

API updates:

- Addition of message id and quoted message id parameters to the Event: Message Received From Bot User, quoted message contents can now be retrieved

- Fully deprecated API: Get Bot Subscriber List, with respect to the removal of the subcription layer. Please consider alternative solution to achieve similar outcomes 

## 26 Feb 2025

API updates: Addition of email and employee code fields to responses

- We've heard your feedback that it can be difficult to retrieve user emails and employee codes! 

- Various APIs have been updated to add these fields, allowing for more seamless integrations. Please refer to our API docs for further details.

- APIs and Events updated: Check Employee Existence

- Get Departments 

- Get Department Employees

- Get Message by Message ID 

- Event: Message Received From Bot User

- Event: New Mentioned Message From Group Chat 

- Event: Interactive Message Click

- Get Approval Item

- Get Thread by Thread ID 

- Event: Bot Added To Group Chat

- Get Group Info

- Event: Bot Removed From Group Chat

- Get Chat History

## 

## 06 Feb 2025

Subscription layer removal for all bots

- With the removal of the subscription layer for all bots users can now chat with bots in their service scope without having to subscribe to it.

- Impact on bots' development: API Changes: The "Send Message to a Bot Subscriber" API will be updated, the validation requiring user subscription will be removed. The "Get Bot Subscriber List" and the event "New Bot Subscriber" will be deprecated.

- App Changes: Users will no longer see a "Subscribe" button on bot profile pages. Instead, the "Message" button will always be present, streamlining user access.

- Review Your Bot's Logic: Ensure that any feature relying on the "API: Get Bot Subscriber List", "Event: New Bot Subscriber" and any subscription-based interactions is adjusted accordingly.

## 28 Nov 2024

Bots can now receive images, files and videos from private chats!

- With the release of SeaTalk v3.50.0, the SeaTalk UI for private chatrooms with bots now supports sending images, files and videos

- Update your app to experience this functionality!

## 14 Nov 2024

APIs updated to allow bots to receive images, files and videos 

- The following APIs/events can now support tag types "image", "video" and "file" Event: New Message Received from Bot User

- Get Message by Message ID

- Get Chat History 

- Get Thread by Thread ID

Coming soon in SeaTalk v3.50.0

- SeaTalk UI for 1-1 chatrooms with bots will allow users to send images, files and videos

- Estimated release date: 28 Nov 2024

## 17 October 2024

#### New API "Update Message" to update sent interactive message card

- #### Update Message API https://open.seatalk.io/docs/Update-Interactive-Message-Card

## 18 July 2024

#### New API "Delete Employee Profile"

- Delete Employee API https://open.seatalk.io/docs/Delete-Employee

#### New Parameter "Offboarding_time" to be returned in "Get Employee Profile" API

- Get Employee Profile API https://open.seatalk.io/docs/get-employee-profile

## 6 June 2024

Effective Date:
API Updates:&nbsp;Effective from 11 June 2024.
Interacting with Bots in Threads on SeaTalk App: Requires SeaTalk App version 3.44.5 or above, releasing on 14 June 2024, for full functionality.

#### Thread Support for Bots

Introduce support for bots to interact with threads in group chats. Effective from 11 June 2024.

- Sending Messages to Threads: Bots can now send replies to specific threads using thread_id. 

- Receiving Mentions in Threads: Event updates will include thread_id to indicate mentions in threads.

- Retrieving Threads: Fetch entire conversation threads using thread_id.

- Existing APIs, such as getting messages by message_id and getting chat history, will now include thread_id in the response.

## 17 May 2024

#### New parameter "last_edited_time" to return the time of the most recent message edit

- Get Message by Message ID API https://open.seatalk.io/docs/Get-Message-by-Message-ID

## 16 Nov 2023

#### Bot and System Account Enhancement

Introduce support for sending formatted messages using markdown in the "text" message type.

- [System Account] https://open.seatalk.io/docs/system-account#Send%20a%20Message-2

- [1-on-1 Bot] https://open.seatalk.io/docs/messaging_send-message-to-bot-subscriber_

- [Group Bot] https://open.seatalk.io/docs/Send-Message-to-Group-Chat

- [Overview of supported message formats] https://open.seatalk.io/docs/format-a-message

## 15 Sept 2023

#### Bot Enhancement

- New API to get quoted message content by message ID

## 14 Sept 2023

#### Approval Center - Create / Update Approval Item API

- The app_path field is now an optional field to cater for lightweight approval scenarios.

- Please take note that app_path field is still required if the action_button field is set to 2.

- The doc of Create Approval Item API and Update Approval Item API has been updated accordingly.

## 7 Sept 2023

#### Bot Enhancement

- New API to support get Bot's joined group chat list

- New API to support get Bot's subscriber list

- Bot can send Image messages to subscribers in 1-on-1 chat

## 5 July 2023

#### Group Chat Bot Capability

- Support bots to interact with users in group chats. See more at Quickly build a Bot for more detail.

- This capability is effective from SeaTalk client version 3.33.

## 16 June 2023

#### Configuration 

RN SDK - getSystemInfo (https://open.seatalk.io/docs/rn-sdk-apis_configuration)

- New parameter called 'theme' added to provide SeaTalk client appearance settings for RN Apps.

RN SDK - onListenerThemeChange

- New method added to provide a listener in RN Apps on SeaTalk client appearance changes.

## 17 March 2023

#### Workspace App 

RN SDK - Calendar Picker API (https://open.seatalk.io/docs/rn-sdk-apis_widgets#Calendar%20Picker-4)

- Two new parameters called 'selectableDateStart' and 'selectableDateEnd' are added to support cases when certain dates need to be disabled from selection.

## 29 December 2022

#### Server API

Send Service Notice (New) (/docs/messaging_send-service-notice)

- A new parameter called "usable_platform" is added to support cases where a service notice message is usable on mobile/desktop platforms only, effective from SeaTalk client version 3.27 for iOS and Desktop and version 3.28 for Android

## 1 December 2022

#### App Link

- App Link, a new common capability, supports SeaTalk users to enter a specific app page quickly through a link generated with standard protocols either in or out of the SeaTalk app. See App Link Overview for more detail.

- This capability is effective from SeaTalk client version 3.26.

## 16 September 2022

#### General Changes 

Open Platform Documentation 

- You can now search through our documents by keywords

#### SeaTalk Developer Tool

- Debug your web app through our SeaTalk Developer Tool, available for Mac and Windows 

#### Workspace App 

General 

- IMPORTANT We will update Top Navigation Bar system for both RN App and Web App in 13 October for a unified UI/UX experience. New Top Navigation Bar will be provaided by SeaTalk Native instead of RN App. Existing RN Apps will need to adapt to this new top navigation bar system as soon as possible by removing the component from your code. 

Web SDK 

- New SOP Web SDK Demo App to allow you test and experiment our Web SDK APIs on SeaTalk Client 

- New Scan QR Code API to allow user scan QR Codes using their device camera 

RN SDK 

- New Media File Picker API to allow user upload image & video through album and device camera

- New Scan QR Code API to allow user scan QR Codes using their device camera 

#### Server API

General 

- IMPORTANT Standardize error handling for all existing APIs, you can find new error code in Error Code Reference doc or each API document for the updated error codes