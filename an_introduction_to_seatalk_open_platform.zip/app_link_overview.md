# App Link Overview

**Source:** https://open.seatalk.io/docs/app-link-overview

Please note that the minimum mobile client version required for App Link is 3.26.

App links support SeaTalk users to enter a specific app page quickly through a link generated with standard protocols either in or out of the SeaTalk app:

- When accessed within SeaTalk, the app link jumps directly to the specified page of an app.

- When accessed outside SeaTalk, depending on the environment and situation, the app link jumps to an intermediate landing page, pulls up SeaTalk and jumps to the specific app page, or guides users to download SeaTalk instead.

This overview introduces when to use app links, the user experiences and how to generate and use app links.

## When to Use App Links

App links can meet your needs if:

- You want to direct your users to a specific app page inside SeaTalk conveniently

- You want your users to be able to visit a specific app page from outside SeaTalk through a link or QR code

- You want to promote your apps in and out of SeaTalk easily

## User Experience

Depending on where the link is accessed and your app's settings, the user experience will be different.

### Access an App Link Inside SeaTalk

Currently, an app link can only be shown in plain text format in SeaTalk.

#### Desktop

- After users click on the app link, they will be directed to the specific app page on the Workspace tab if the app link is valid.

- If the app link is invalid and a fallback page is provided, users will be directed to the fallback page on their default browser.

- If the app link is invalid and no fallback page is provided, users will see a default error page on Workspace saying that the app link is invalid.

#### Mobile

For RN app:

- After users click on the app link, they will be directed to the specific RN app page if the app link is valid.

- If the app link is invalid, users will be directed to the homepage of the RN app instead.

For Web app:

- After users click on the app link, they will be directed to the specific app page if the app link is valid.

- If the app link is invalid and a fallback page is provided, users will be directed to the fallback page on their default browser.

- If the app link is invalid and no fallback page is provided, users will see a default error page on Workspace saying that the app link is invalid.

### Access an App Link Outside SeaTalk

#### Desktop

- After users click on the app link, they will be directed to an intermediate landing page on the default browser if the app link is valid. If the app link is not valid, users will see an error page saying that the app link is invalid on the landing page.

- The intermediate landing page will attempt to pull up SeaTalk, after which users will be directed to the specific app page on the Workspace tab. If the pull-up fails, the fallback page configured by the app will be shown if it is provided upon the app link generation.

Note: if the app link is clicked on a SeaTalk web client, it will be treated as accessed outside SeaTalk.

See the screenshots below for the intermediate landing pages opened on a default browser.

![A3oxOOQUABCcVxcWEaYBACc](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOOQUABCcVxcWEaYBACc?sign=1672987666.1942844-Sf8he-0-78a5c81185961120698d8627b4e760c0)

#### Mobile

For RN app:

- After users click on the app link/scan a QR code generated with the app link, they will be directed to an intermediate landing page on the default browser if the app link is valid. If the app link is not valid, users will see an error page saying that the app link is invalid on the landing page.

- The intermediate landing page will attempt to pull up SeaTalk, after which users will be directed to the specific app page on SeaTalk. If the pull-up fails, the fallback page configured by the app will be shown if it is provided upon the app link generation.

For Web app:

- After users click on the app link/scan a QR code generated with the app link, they will be directed to an intermediate landing page on the default browser if the app link is valid. If the app link is not valid, users will see an error page saying that the app link is invalid on the landing page.

- The intermediate landing page will attempt to pull up SeaTalk, after which users will be directed to the specific app page on SeaTalk. If the pull-up fails, the fallback page configured by the app will be shown if it is provided upon the app link generation.

See the screenshots below for the intermediate landing pages opened on a default browser.

![A3oxOJyCAHSjTxcWEaYAACc](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOJyCAHSjTxcWEaYAACc?sign=1672987535.5949147-RfFq8-0-16afd7c1900507164b7d32e613d79d37)

Note: if the app link is accessed in WeChat, users need to tap on the menu on the top-right corner and select "Open in the default browser" option to proceed.

![A3oxODmFALy6UxcWEaYAACc](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxODmFALy6UxcWEaYAACc?sign=1672987602.6205893-eRtO9-0-e70694be3b54a7ab5bb1205e2877958b)

## Ready to Start?

App Link is one of the SeaTalk open platform app's capabilities, so to tap into this capability you need to create a SeaTalk Open Platform app with the Workspace capability to generate and access app links. To learn more about how to create and configure an app, see Build an App For Your Team (../../../../../../docs/build-an-app-for-your-team).

When you are ready with your app, refer to the following two server APIs:

- Generate an App Link

- Get Original App Link Detail