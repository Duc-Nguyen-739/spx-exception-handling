# Create Department 

**Source:** https://open.seatalk.io/docs/create-department

## API Description

Use this API to create a new department in your organization. 

Note:

- This API requires Create, Update, and Delete a Department permission

Request Method: `POST`

End Point: https://openapi.seatalk.io/oa_sync/departments/create (https://openapi.seatalk.io/oa_sync/departments/create)

## Request Parameter

Header

| Parameter | Type | Mandatory | Description | Default | Sample |
| --- | --- | --- | --- | --- | --- |
| Authorization | string | Yes | Obtained through the Get App Access Token API | N/A | Bearer c8bda0f77ef940c5bea9f23b2d7fc0d8 |
| Content-Type | string | Yes | Request header format | N/A | application/json |

Body (JSON)

| Parameter | Type | Mandatory | Size Limit | Description | Default | Sample |
| --- | --- | --- | --- | --- | --- | --- |
| departments | []Department | Yes | | A list of Departments | N/A | |

Department

| Parameter | Type | Mandatory | Size Limit | Description | Default | Sample |
| --- | --- | --- | --- | --- | --- | --- |
| department_name | string | Yes | | The department name | | |
| department_code | string | No | 128 Characters | - The optional field for the new department's department_code - If no value is given, SeaTalk will generate a random value for the department as its department_code | | |
| department_alias | string | No | 128 Characters | The optional field for the new department's alias | | |
| parent_department | string | Yes | | The department code of the parent department of this new department | | |
| visibility | int | | | 0: visible to only its sub-departments 1: visible to the specified department whitelist | | |
| department_lead | string | | | The employee_code of the department leader | | |
| visible_to_departments | string[] | | | - A list of department_code of departments to which the new department is visible - Must be passed in if "visibility" is 1 | | |

## Response Parameter

Body (JSON)

| Parameters | Type | Description |
| --- | --- | --- |
| code | int | Refer to Error Code for explanations |
| message | string | Error Message |
| rid | string | Request id |
| result | DepartmentOperationResults | Operation result |

DepartmentOperationResults

| Parameters | Type | Description |
| --- | --- | --- |
| departments | []DepartmentOperationResult | The operation results |
| total_num | int | The total number of departments in the request |
| success_num | int | The total number of successfully created departments in the request |
| fail_num | int | The total number of failed departments in the request |

DepartmentOperationResult

| Parameters | Type | Description |
| --- | --- | --- |
| department_code | string | The OA ErrCode |
| error | int | 0: success |
| error_message | string | The error message |