# Build a Workspace App 

**Source:** https://open.seatalk.io/docs/How-to-Build-a-Workspace-App

In this article, we will guide you to quickly build a Workspace App and display an entrance in your SeaTalk Workspace

## What Can a Workspace App Do?

A Workspace App allows you to integrate web pages and/or RN (React Native) pages into SeaTalk client. They are represented as Web Apps and RN Apps on our platform. For a Workspace App to work properly, you will need to provide valid technical details for corresponding capabilities:

- A valid Web URL for Web App

- An RN Bundle for RN App 

Currently, Web Apps are allowed to be used in both mobile and desktop client, RN Apps are allowed to be used only in mobile client. 

Let's take a look at how to quickly build a Workspace App and setup a Web URL and an RN Bundle. 

## Step 1: Create a Workspace App 

From open.seatalk.io (https://open.seatalk.io/), click on "Start building" or "Create app" to trigger the app creation wizard. You can also trigger this by clicking "Create app" from you app list. Follow the steps in the wizard to complete the basic configuration of your app.

Step 1: Basic app information

![](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOJr8AGSVtM5jESgJACc?sign=1756434867.5723364-nxaFp-0-e7dd935966d3bcc9360d472836abe4bb)

Step 2: Service and data scope configuration

![](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOJvcAAwhwM5jEcAFACc?sign=1756435056.7253425-h0hSl-0-b6868db00283b997802cf654d6891516)

Your new app will have a default status of Not Configured. Learn more about app statuses. (https://open.seatalk.io/docs/SOP-App-Statuses) Click the Enable button in the Workspace app card in the Capability section.

![](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOHV3ADw4yc5jEcMJACc?sign=1756435205.6689725-BziRp-0-edabdace05626dfdba640f947e250d0e)

![](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOLx9AGygy85jEW4JACc?sign=1756435245.1118505-dBQhf-0-850e6eb04ff3d2b078dd0183f19e8804)

Once a capability is successfully enabled, it will appear in the menu on the left hand side of the page, and you will be directed to the capability configuration menu of the newly added capability. Additionally, default API permissions for the capability will be enabled for your app.

## Step 2: Setup and Release Web URL

We will demonstrate how to setup Web URL first 

- Step 2.1: Clicks "Web App" button on the left, then you will be redirected to your app's Web App setting page. Click the "Edit" button on the top right corner to configure Web App URL and click "Save" button to save the chang. 

- You can choose different Web URLs for your mobile and desktop client. 

![](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOLHXAIyB7M5jEZ4CACc?sign=1756435783.8035007-rbjKq-0-b882931f572e1b7294c71ff1c0d89424)

![](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOARkAPADFc9jEcwLACc?sign=1756436447.501951-KudXE-0-ee804b3280517a37d6a8dfa9acb5007b)

- Step 2.2: After saving your change, go to "Release" page under Workspace App section, and click "Create New Release" button to create a new release 

![](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOJA6AKy6885jETILACc?sign=1756435902.142471-HLlpC-0-bb8ebd2b4d7bdbad4c277070b791c171)

- Step 2.3: Fill in Release Info and select Web App in both "Capability Setting" => "Mobile Workspace" &"Capability Setting" => "Desktop Workspace" and click Release

![](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOJhfAKQ21O9kEYoIACc?sign=1757647539.6385674-iJfOA-0-4c4b77db4a9fe29a41510099611248fa)

- Congratulations! You have just release your first Workspace App with Web App capability. You should be able to see it in your mobile and desktop clients' Workspace Tab. 

## Step 3: Setup and Release RN Bundle

We will now demonstrate how to setup RN Bundle and RN Capability 

- Step 3.1: We will create an RN Bundle first, you can follow the document in this link to create an RN Bundle through our CLI tool. Remember to select RN App when creating a new project. 

- Step 3.2: Go to RN App page and click "Upload App Bundle" button, and select the newly created RN Bundle 

![](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOFLFABApf89jEVQDACc?sign=1756438186.636788-u0rE5-0-4e6bc050e645cf3eadbc900acd3e4253) ![](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOEGGAMzjdc9jEREIACc?sign=1756438034.704967-mUHKf-0-af5eed267d2b852dee1f47a98c2b3b3c)

- Step 3.3: Go to Release Page and select RN App in Capability Setting => Mobile Workspace section and release. 

![](https://sos.sp-cdn.shopee.com/c3/53693910/sos/A3oxOJH4AAh0w-9kEaIEACc?sign=1757647265.0926049-F1b7n-0-77ccbba97a3893cc413e5e1f1a1a51ea)

- Step 3.4: Now you should be able to see your newly released RN App in Workspace tab on your mobile client 

Well done! Now we have release a Workspace App with both Web App and RN App capability to your workspace. You can follow the following documents to get improve your app and release it to more user:

- Web App development example: https://open.seatalk.io/docs/web-sdk_web-app-example

- RN App development example: https://open.seatalk.io/docs/rn-sdk-guide_get-started

- Release to more user: https://open.seatalk.io/docs/build-an-app-for-your-team