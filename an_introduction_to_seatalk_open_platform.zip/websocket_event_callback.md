# WebSocket Event Callback

**Source:** https://open.seatalk.io/docs/WebSocket-Event-Callback

SeaTalk Open Platform supports receiving event callbacks via persistent WebSocket connections. Unlike URL Callback (https://open.seatalk.io/docs/event-callback), WebSocket does not require a publicly accessible server — your bot can receive real-time events from a local machine or an internal server with outbound internet access only.

Each bot can only use one event delivery method at a time. For a comparison of URL Callback and WebSocket, see Event Callback (https://open.seatalk.io/docs/event-callback).

For the full list of supported events, see List of Events (https://open.seatalk.io/docs/list-of-events).

### Before You Start

You will need:

- Your bot's App ID and App Secret, available from the Developer Portal

- The WebSocket SDK — download from the SDK page. Go and Python SDKs are currently supported.

### Quick Start

The SDK handles the connection lifecycle for you: it registers with the platform using your credentials, maintains the heartbeat, dispatches incoming events to your handlers, and automatically acknowledges each event after your handler returns successfully.

#### Go

```
package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"

	seatalkoapisdk "git.garena.com/seatalk/seatalk-oapi-sdk-go"
)

func main() {
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	dispatcher := seatalkoapisdk.NewEventDispatcher().
		OnMessageFromBotSubscriber(func(ctx context.Context, event *seatalkoapisdk.MessageFromBotSubscriberEvent) error {
			if event.Event.Message.Tag == seatalkoapisdk.MessageTagText && event.Event.Message.Text != nil {
				fmt.Printf("message from %s: %s\n",
					event.Event.SeaTalkID, event.Event.Message.Text.Content)
			}
			return nil
		})

	client := seatalkoapisdk.NewClient(
		"your-app-id",
		"your-app-secret",
		seatalkoapisdk.WithEventDispatcher(dispatcher),
	)
	defer client.Close()

	if err := client.Run(ctx); err != nil {
		log.Fatal(err)
	}
}
```

```

```

#### Python

```
from seatalk_oapi_sdk import Client, EventDispatcher, MESSAGE_TAG_TEXT

def handle_message(event):
message = event.event.message
if message.tag == MESSAGE_TAG_TEXT and message.text is not None:
print(f"message from {event.event.seatalk_id}: {message.text.content}")

client = Client(
app_id="your-app-id",
app_secret="your-app-secret",
dispatcher=EventDispatcher().on_message_from_bot_subscriber(handle_message),
)

try:
client.run()
finally:
client.close()
```

```

```

### Handling Multiple Event Types

To handle more than one event type, chain additional handlers on the dispatcher.

Go

```
dispatcher := seatalkoapisdk.NewEventDispatcher().
OnMessageFromBotSubscriber(handleMessage).
OnUserEnterChatroomWithBot(handleUserEnter).
OnBotAddedToGroupChat(handleBotAdded).
OnBotRemovedFromGroupChat(handleBotRemoved).
OnNewMentionedMessageReceivedFromGroupChat(handleGroupMention).
OnInteractiveMessageClick(handleClick).
OnNewMessageReceivedFromThread(handleThreadMessage).
OnGroupChatConvertedToExternalGroup(handleGroupConverted)
```

```

```

Python

```
dispatcher = (
EventDispatcher()
.on_message_from_bot_subscriber(handle_message)
.on_user_enter_chatroom_with_bot(handle_user_enter)
.on_bot_added_to_group_chat(handle_bot_added)
.on_bot_removed_from_group_chat(handle_bot_removed)
.on_new_mentioned_message_received_from_group_chat(handle_group_mention)
.on_interactive_message_click(handle_click)
.on_new_message_received_from_thread(handle_thread_message)
.on_group_chat_converted_to_external_group(handle_group_converted)
)
```

```

```

#### Supported Event Types

- For full field references for each event, see List of Events.

### Configure WebSocket in the Developer Portal

After starting your WebSocket process and confirming the connection is active, switch your bot's event delivery method to WebSocket in the Developer Portal:

- Go to the Developer Portal and open your app's configuration page.

- Click Event Callback in the left navigation menu.

- Select WebSocket as the event receiving method.

- Click Re-verify to confirm the connection. The platform checks that your process is connected before saving the setting.

Note: The event delivery method can only be set to WebSocket while your process is running and connected. If the process is stopped, event delivery will pause until it reconnects.