# Delete Department 

**Source:** https://open.seatalk.io/docs/delete-department

## API Description

Use this API to delete a department in your organization. 

Note:

- This API requires Create, Update, and Delete a Department permission

- To successfully delete a department, make sure there is no employee under that department

Request Method: `POST`

End Point: https://openapi.seatalk.io/oa_sync/departments/delete (https://openapi.seatalk.io/oa_sync/departments/delete)

## Request Parameter

Header

| Parameter | Type | Mandatory | Description | Default | Sample |
| --- | --- | --- | --- | --- | --- |
| Content-Type | string | Yes | | | application/json |
| Authorization | string | Yes | Obtained through the Get App Access Token API | N/A | Bearer c8bda0f77ef940c5bea9f23b2d7fc0d8 |

Parameter

| Parameter | Type | Mandatory | Description | Default | Sample |
| --- | --- | --- | --- | --- | --- |
| department_code | string | Yes | The department code of the very department to be deleted | | |

## Response Parameter

Body(JSON)

| Parameters | Type | Description |
| --- | --- | --- |
| code | int | Refer to Error Code |
| rid | string | Request id |
| oa_result | OAResult | Error reason |

OAResult

| Parameters | Type | Description |
| --- | --- | --- |
| oa_error | int | OA ErrCode |
| oa_message | string | Error reason |